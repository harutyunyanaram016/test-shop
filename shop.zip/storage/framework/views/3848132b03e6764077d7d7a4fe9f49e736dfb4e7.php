<?php $__env->startSection('title'); ?> Create User <?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs', Breadcrumbs::render('admin.dashboard.users.create')); ?>


<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-lg-6 mt-4">

            <h1>Create user</h1>

            <?php echo Form::open(['action' => 'Admin\AdminUsersController@store']); ?>


            <div class="form-group">
                <?php echo Form::label('email', 'Email *'); ?>
                <?php echo Form::email('email', null, ['class' => $errors->has('email') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('email')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('role_id', 'Role *'); ?>
                <?php echo Form::select('role_id', array(''=>'Choose Option') + $roles, 1,  ['class' => $errors->has('role_id') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('role_id')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('role_id')); ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('password', 'Password *'); ?>
                <?php echo Form::password('password', ['class' => $errors->has('password') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('password')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div>
                <?php endif; ?>
            </div>

            <div class= "form-group" >
                <?php echo Form::label('name', 'Name'); ?>
                <?php echo Form::text('name', null, ['class' => $errors->has('name') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('surname', 'Surname'); ?>
                <?php echo Form::text('surname', null, ['class' => 'form-control']); ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('phone', 'Phone'); ?>
                <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('date_of_birth', 'Date of birth'); ?>
                <?php echo Form::date('date_of_birth', null, ['class' => 'form-control']); ?>
            </div>


            <div class="form-group">
                <?php echo Form::token(); ?>
                <?php echo Form::submit('Create User', ['class'=>'btn brn-primary btn-block']); ?>
            </div>


            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>