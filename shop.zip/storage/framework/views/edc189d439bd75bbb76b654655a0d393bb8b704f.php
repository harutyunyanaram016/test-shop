<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Admin Panel - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(asset('css/adminlibs.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('head'); ?>

</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">



<!-- Navigation-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="<?php echo e(route('admin.index')); ?>">Admin Panel | <?php echo e(Auth::user()->name); ?></a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
                <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">
                    <i class="fa fa-fw fa-dashboard"></i>
                    <span class="nav-link-text">Dashboard</span>
                </a>
            </li>

            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Users">
                <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseUsers" data-parent="#exampleAccordion">
                    <i class="fa fa-fw fa-users"></i>
                    <span class="nav-link-text">Users</span>
                </a>
                <ul class="sidenav-second-level collapse" id="collapseUsers">
                    <li>
                        <a href="<?php echo e(route('admin.users.create')); ?>">Create User</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.users.index')); ?>">Users list</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Products">
                <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseProducts" data-parent="#exampleAccordion">
                    <i class="fa fa-fw fa-television"></i>
                    <span class="nav-link-text">Products</span>
                </a>
                <ul class="sidenav-second-level collapse" id="collapseProducts">
                    <li>
                        <a href="<?php echo e(route('admin.products.create')); ?>">Create Product</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.products.index')); ?>">Products list</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="FAQ">
                <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseFaq">
                    <i class="fa fa-fw fa-question"></i>
                    <span class="nav-link-text">FAQ</span>
                </a>
                <ul class="sidenav-second-level collapse" id="collapseFaq">
                    <li>
                        <a href="<?php echo e(route('admin.faqs.create')); ?>">Create FAQ</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.faqs.index')); ?>">FAQ list</a>
                    </li>
                </ul>
            </li>


            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
                <a class="nav-link" href="<?php echo e(route('admin.categories.index')); ?>">
                    <i class="fa fa-fw fa-th-list"></i>
                    <span class="nav-link-text">Categories</span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Orders">
                <a class="nav-link" href="<?php echo e(route('admin.orders.index')); ?>">
                    <i class="fa fa-fw fa-shopping-cart"></i>
                    <span class="nav-link-text">Orders</span>
                </a>
            </li>

            
                
                    
                    
                
            
        </ul>
        <ul class="navbar-nav sidenav-toggler">
            <li class="nav-item">
                <a class="nav-link text-center" id="sidenavToggler">
                    <i class="fa fa-fw fa-angle-left"></i>
                </a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            
                
                    
                    
              
            
                    
              
            
                
                
                    
                    
                    
                        
                        
                        
                    
                    
                    
                        
                        
                        
                    
                    
                    
                        
                        
                        
                    
                    
                    
                
            
            
                
                    
                    
              
            
                    
              
            
                
                
                    
                    
                    
              
                
                  
              
                        
                        
                    
                    
                    
              
                
                  
              
                        
                        
                    
                    
                    
              
                
                  
              
                        
                        
                    
                    
                    
                
            
            
                
                    
                        
                        
                
                  
                
              
                    
                
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('mainpage')); ?>">
                    <i class="fa fa-fw fa-sign-out"></i>Back to page
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
                    <i class="fa fa-fw fa-power-off"></i>Logout
                </a>
            </li>
        </ul>
    </div>
</nav>
<!-- END Navigation-->






<div class="content-wrapper">
    <div class="container-fluid">

        <?php echo $__env->yieldContent('breadcrumbs'); ?>

        <?php echo $__env->yieldContent('content'); ?>

    </div>
    <!-- /.container-fluid-->
</div>
    <!-- /.content-wrapper-->



    <footer class="sticky-footer">
        <div class="container">
            <div class="text-center">
                <small>Copyright © Shop 2018</small>
            </div>
        </div>
    </footer>


    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fa fa-angle-up"></i>
    </a>


    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>
                    </form>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</button>
                </div>
            </div>
        </div>
    </div>
    <!-- END Logout Modal-->

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('js/adminlibs.js')); ?>"></script>

    <!-- Custom scripts for this page-->
    <script src="<?php echo e(asset('js/consts/sb-admin-datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/consts/sb-admin-charts.js')); ?>"></script>
<?php echo $__env->yieldContent('modal'); ?>
</body>

</html>
