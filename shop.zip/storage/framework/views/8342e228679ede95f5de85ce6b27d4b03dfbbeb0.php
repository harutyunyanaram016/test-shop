<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="<?php echo e(asset('css/libs.css')); ?>" rel="stylesheet">
    <style>
        @media  only screen and (min-width: 1079px) {
            .my-pull-right{
                float: right !important;
            }
        }
    </style>
    <!-- fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(url('/')); ?>/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(url('/')); ?>/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(url('/')); ?>/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(url('/')); ?>/images/ico/apple-touch-icon-57-precomposed.png">
    <style type="text/css" id="enject"></style>
</head>


<body>
<div id="header">
    <div class="container">
                <div id="welcomeLine" class="row">
                        <?php if(auth()->guard()->guest()): ?>
                        <div class="span6">Please <strong><a href="<?php echo e(route('login')); ?>">Login</a></strong> or  <strong> <a href="<?php echo e(route('register')); ?>">Register</a></strong></div>

                        <?php else: ?>

                        <div class="span6">Welcome!<strong> <?php echo e(Auth::user()->name); ?></strong></div>

                        <?php endif; ?>

                    <div class="span6">
                        <div class="pull-right">
                            <?php if($cart): ?>
                                <a href="<?php echo e(route('orders.show')); ?>"><span class="btn btn-mini"><span class="my-total-price"><?php echo e($cart->totalPrice); ?></span> zł</span></a>
                                <a href="<?php echo e(route('orders.show')); ?>"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> <span class="my-total-qty"> <?php echo e($cart->totalQty); ?></span> Itemes in your cart </span> </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('orders.show')); ?>"><span class="btn btn-mini">0 zł</span></a>
                                <a href="<?php echo e(route('orders.show')); ?>"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> [ 0 ] Itemes in your cart </span> </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

        <!-- Navbar ================================================== -->
        <div id="logoArea" class="navbar">
            <a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <div class="navbar-inner">
                <a class="brand" href="<?php echo e(route('mainpage')); ?>"><img src="<?php echo e(url('/')); ?>/images/logo.png" alt="Bootsshop"/></a>


                <?php if(isset($categories)): ?>

                    <?php if(count($categories)): ?>
                    <?php echo Form::open(['method'=>'GET', 'action' => 'ProductsController@search', 'class'=> 'form-inline navbar-search']); ?>


                            <?php echo Form::text('search', null, ['class' => 'srchTxt', 'id'=> 'srchFld', 'style'=>'padding-left:28px;']); ?>

                            <?php echo Form::select('category_id', array(''=>'ALL') + $categoriesPluck , null,  ['class' => 'srchTxt']); ?>


                                <?php echo Form::submit('Search', ['class'=>'btn btn-primary']); ?>


                    <?php echo Form::close(); ?>

                    <?php endif; ?>
                <?php endif; ?>

                <ul id="topMenu" class="nav my-pull-right">
                    <li class=""><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>

                    <?php if(auth()->guard()->check()): ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($auth->name); ?> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <?php if($auth->isAdmin()): ?>
                                <li><a href="<?php echo e(route('admin.index')); ?>">Admin Panel</a></li>
                            <?php endif; ?>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>

                    
                        
                        
                            
                                
                                
                            
                            
                                
                                    
                                        
                                    
                                    
                                        
                                    
                                    
                                        
                                            
                                        
                                    
                                
                                
                                
                            
                        
                    
                </ul>
            </div>
        </div>
        <!-- END Navbar ================================================== -->

    </div>
</div>
<!-- Header End====================================================================== -->


<?php echo $__env->yieldContent('carousel'); ?>


<div id="mainBody">
    <div class="container">
        <div class="row">
            <!-- Sidebar ================================================== -->
            <div id="sidebar" class="span3">
                <?php if($cart): ?>
                    <div class="well well-small"><a id="myCart" href="<?php echo e(route('orders.show')); ?>"><img src="<?php echo e(url('/')); ?>/images/ico-cart.png" alt="cart"><span class="my-total-qty"><?php echo e($cart->totalQty); ?></span> Items in your cart  <span class="badge badge-warning pull-right"><span class="my-total-price"><?php echo e($cart->totalPrice); ?></span> zł</span></a></div>
                <?php else: ?>
                    <div class="well well-small"><a id="myCart" href="<?php echo e(route('orders.show')); ?>"><img src="<?php echo e(url('/')); ?>/images/ico-cart.png" alt="cart">0 Items in your cart  <span class="badge badge-warning pull-right">0 zł</span></a></div>

                <?php endif; ?>
                <ul id="sideManu" class="nav nav-tabs nav-stacked">

                    <?php if(isset($categories)): ?>
                        <?php if(count($categories)): ?>

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="subMenu"><a> <?php echo e(strtoupper($category->name)); ?> [ <?php echo e($category->products->count()); ?> ]</a>
                                <?php if(count($category->subcategories)): ?>
                                        <ul style="display:none">
                                            <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e(route('products.productsBySubcategory', $subcategory->id)); ?>"> <i class="icon-chevron-right"></i> <?php echo e($subcategory->name); ?> ( <?php echo e($subcategory->products->count()); ?> )</a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>

                                <?php endif; ?>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                        <?php endif; ?>
                    <?php endif; ?>

                </ul>
                <br/>
                    <?php if($twoproducts): ?>
                        <?php $__currentLoopData = $twoproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="thumbnail">
                                <a href="<?php echo e(route('products.details', $oneproduct->id)); ?>"><img src="<?php echo e(url('/')); ?><?php echo e($oneproduct->icon->file); ?>" alt="<?php echo e($oneproduct->brand); ?> <?php echo e($oneproduct->model); ?>"/></a>
                                <div class="caption">
                                    <h5><a href="<?php echo e(route('products.details', $oneproduct->id)); ?>"><?php echo e($oneproduct->brand); ?> <?php echo e($oneproduct->model); ?></a></h5>
                                    <h4 style="text-align:center"><a class="btn" href="<?php echo e(route('products.details', $oneproduct->id)); ?>"> <i class="icon-zoom-in"></i></a> <a class="btn" href="<?php echo e(route('products.addProductsToCart',[$oneproduct->id, 1])); ?>">Add to <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href=""><?php echo e($oneproduct->price); ?>zł</a></h4>
                                </div>
                            </div><br/>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>


            </div>
            <!-- Sidebar end=============================================== -->
            <div class="span9">

                <?php echo $__env->yieldContent('content'); ?>


            </div>
        </div>
    </div>
</div>
<!-- Footer ================================================================== -->
<div  id="footerSection">
    <div class="container">
        <div class="row">
            <div class="span3">
                <h5>ACCOUNT</h5>
                <a href="#">YOUR ACCOUNT</a>
                <a href="#">PERSONAL INFORMATION</a>
                <a href="#">ADDRESSES</a>
                <a href="#">DISCOUNT</a>
                <a href="#">ORDER HISTORY</a>
            </div>
            <div class="span3">
                <h5>INFORMATION</h5>
                <a href="#">CONTACT</a>
                <a href="<?php echo e(route('register')); ?>">REGISTRATION</a>
                <a href="#">LEGAL NOTICE</a>
                <a href="<?php echo e(route('faq')); ?>">TERMS AND CONDITIONS</a>
                <a href="<?php echo e(route('faq')); ?>">FAQ</a>
            </div>
            <div class="span3">
                <h5>OUR OFFERS</h5>
                <a href="#">NEW PRODUCTS</a>
                <a href="#">TOP SELLERS</a>
                <a href="#">SPECIAL OFFERS</a>
                <a href="#">MANUFACTURERS</a>
                <a href="#">SUPPLIERS</a>
            </div>
            <div id="socialMedia" class="span3 pull-right">
                <h5>SOCIAL MEDIA </h5>
                <a href="#"><img width="60" height="60" src="<?php echo e(url('/')); ?>/images/facebook.png" title="facebook" alt="facebook"/></a>
                <a href="#"><img width="60" height="60" src="<?php echo e(url('/')); ?>/images/twitter.png" title="twitter" alt="twitter"/></a>
                <a href="#"><img width="60" height="60" src="<?php echo e(url('/')); ?>/images/youtube.png" title="youtube" alt="youtube"/></a>
            </div>
        </div>
        <p class="pull-right">&copy; Bootshop</p>
    </div><!-- Container End -->
</div>
<!-- Placed at the end of the document so the pages load faster ============================================= -->



<script src="<?php echo e(asset('js/libs.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>


</body>
</html>