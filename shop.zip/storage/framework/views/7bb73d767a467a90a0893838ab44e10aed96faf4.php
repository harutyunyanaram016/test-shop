<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs', Breadcrumbs::render('admin.dashboard')); ?>


<?php $__env->startSection('content'); ?>


    <!-- Icon Cards-->

    <div class="row">
        <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
                <div class="card-body">
                    <div class="card-body-icon">
                        <i class="fa fa-fw fa-users"></i>
                    </div>
                    <div class="mr-5"><?php echo e($users_count); ?> Users!</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="<?php echo e(route('admin.users.index')); ?>">
                    <span class="float-left">View Details</span>
                    <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                </a>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-warning o-hidden h-100">
                <div class="card-body">
                    <div class="card-body-icon">
                        <i class="fa fa-fw fa-television"></i>
                    </div>
                    <div class="mr-5"><?php echo e($products_count); ?> Products!</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="<?php echo e(route('admin.products.index')); ?>">
                    <span class="float-left">View Details</span>
                    <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                </a>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-secondary o-hidden h-100">
                <div class="card-body">
                    <div class="card-body-icon">
                        <i class="fa fa-fw fa-list"></i>
                    </div>
                    <div class="mr-5"><?php echo e($categories_count); ?> Categories!</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="<?php echo e(route('admin.categories.index')); ?>">
                    <span class="float-left">View Details</span>
                    <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                </a>
            </div>
        </div>


        <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-success o-hidden h-100">
                <div class="card-body">
                    <div class="card-body-icon">
                        <i class="fa fa-fw fa-shopping-cart"></i>
                    </div>
                    <div class="mr-5"><?php echo e($orders_count); ?> Orders!</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="<?php echo e(route('admin.orders.index')); ?>">
                    <span class="float-left">View Details</span>
                    <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                </a>
            </div>
        </div>
    </div>

    <!-- END Icon Cards-->






    
                
                    
                
                    
                
                
    





    <div class="row">
        <div class="col-lg-8">

            <!-- Example Notifications Card-->
            
                
                    
                
                    
                        
                            
                            
                                
                                
                                
                            
                        
                    
                    
                        
                            
                            
                                
                                
                            
                        
                    
                    
                        
                            
                            
                                
                                
                                
                            
                        
                    
                    
                        
                            
                            
                                
                                
                                
                                
                                
                            
                        
                    
                    
                
                
            
            



        




        
            
                
                    
                
                    
                
                
            
        

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>