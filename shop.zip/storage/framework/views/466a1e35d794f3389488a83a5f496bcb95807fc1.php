<?php $__env->startSection('content'); ?>






    <div class="row">
        <div class="span6">
            <div class="well">
                <h3 style="text-align: center;">LOGIN</h3><br/>
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="control-group <?php echo e($errors->has('email') ? 'error' : ''); ?>">
                        <label class="control-label" for="email">Email adress</label>
                        <div class="controls">
                            <input class="span5"   type="text" id="email" placeholder="Name" name="email" value="<?php echo e(old('email')); ?>">
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>


                    <div class="control-group <?php echo e($errors->has('password') ? 'error' : ''); ?>">
                        <label class="control-label" for="password">Password</label>
                        <div class="controls">
                            <input class="span5"  type="password" id="password" name="password">
                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>


                    <div class="control-group">
                        <label class="control-label" for="checkbox">
                            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                        </label>
                    </div>



                    <div class="controls">
                        <button type="submit" class="btn block">Sign in your account</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="span3" style="text-align: center;">
            <div class="well" style="margin-top: 20px;">
                <h5>NOT REGISTERED YET?</h5>
                <h2><a href="<?php echo e(route('register')); ?>">Register</a></h2>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>