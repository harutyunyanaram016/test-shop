<?php $__env->startSection('content'); ?>


        <div class="row">
                <div class="span6">
                    <div class="well">
                        <h3 style="text-align: center;">CREATE YOUR ACCOUNT</h3><br/>
                        <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo e(csrf_field()); ?>



                            <div class="control-group <?php echo e($errors->has('email') ? 'error' : ''); ?>">
                                <label class="control-label" for="email">Email</label>
                                <div class="controls">
                                    <input class="span5"  type="text" id="email" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                                    <?php if($errors->has('email')): ?>

                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="control-group <?php echo e($errors->has('password') ? 'error' : ''); ?>">
                                <label class="control-label" for="password">Password</label>
                                <div class="controls">
                                    <input class="span5"  type="password" id="password" name="password">
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="control-group">
                                <label class="control-label" for="password-confirm">Confirm password</label>
                                <div class="controls">
                                    <input class="span5"  type="password" id="password-confirm" name="password_confirmation">
                                </div>
                            </div>


                            <div class="control-group <?php echo e($errors->has('name') ? 'error' : ''); ?>">
                                <label class="control-label" for="name">Name</label>
                                <div class="controls">
                                    <input class="span5"   type="text" id="name" placeholder="Name" name="name" value="<?php echo e(old('name')); ?>">
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="control-group <?php echo e($errors->has('surname') ? 'error' : ''); ?>">
                                <label class="control-label" for="name">Surname</label>
                                <div class="controls">
                                    <input class="span5"   type="text" id="surname" placeholder="Surname" name="surname" value="<?php echo e(old('surname')); ?>">
                                    <?php if($errors->has('surname')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('surname')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="control-group <?php echo e($errors->has('phone') ? 'error' : ''); ?>">
                                <label class="control-label" for="name">Phone</label>
                                <div class="controls">
                                    <input class="span5"   type="text" id="phone" placeholder="Phone number" name="phone" value="<?php echo e(old('phone')); ?>">
                                    <?php if($errors->has('phone')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('phone')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="control-group <?php echo e($errors->has('adress') ? 'error' : ''); ?>">
                                <label class="control-label" for="name">Adress</label>
                                <div class="controls">
                                    <input class="span5"   type="text" id="adress" placeholder="Adress" name="adress" value="<?php echo e(old('adress')); ?>">
                                    <?php if($errors->has('adress')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('adress')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="controls" style="text-align: center;">
                                <button type="submit" class="btn block">Create Your Account</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="span3" style="text-align: center;">
                    <div class="well" style="margin-top: 20px;">
                        <h5>ALREADY REGISTERED ?</h5>
                        <h2><a href="<?php echo e(route('login')); ?>">Login</a></h2>
                    </div>
                </div>
        </div>







    
        
            
                

                


                    
                        



                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        






                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        






                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            

                            
                                
                            
                        

                        
                            
                                
                                    
                                
                            
                        
                    
                
            
        
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>