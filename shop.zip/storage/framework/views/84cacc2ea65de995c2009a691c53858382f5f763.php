<?php $__env->startSection('title'); ?> Create Product <?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs', Breadcrumbs::render('admin.dashboard.products.create')); ?>

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-lg-6 mt-4">

            <h1>Create product</h1>

            <?php echo Form::open(['method'=>'POST', 'action' => 'Admin\AdminProductsController@store','files'=>true]); ?>



            <div class= "form-group" >
                <?php echo Form::label('brand', 'Brand *'); ?>
                <?php echo Form::text('brand', null, ['class' => $errors->has('brand') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('brand')): ?>
                    
                    <div class="invalid-feedback"><?php echo e($errors->first('brand')); ?></div>
                <?php endif; ?>
            </div>

            <div class= "form-group" >
                <?php echo Form::label('model', 'Model *'); ?>
                <?php echo Form::text('model', null, ['class' => $errors->has('model') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('model')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('model')); ?></div>
                <?php endif; ?>
            </div>


            <div class= "form-group" >
                <?php echo Form::label('price', 'Price *'); ?>
                <?php echo Form::number('price', null, ['class' => $errors->has('price') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('price')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('price')); ?></div>
                <?php endif; ?>
            </div>

            <div class= "form-group" >
                <?php echo Form::label('description', 'Description *'); ?>
                <?php echo Form::textarea('description', null, ['rows'=>3, 'class' => $errors->has('description') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('description')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('description')); ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('category_id', 'Category *'); ?>
                <?php echo Form::select('category_id', array(''=>'Choose Option') + $categories , null,  ['id'=>'my-category','class' => $errors->has('category_id') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('category_id')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('category_id')); ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('subcategory_id', 'Subcategory *'); ?>
                <?php echo Form::select('subcategory_id', array(''=>'Choose Option'), null,  ['id'=>'my-subcategory','class' => $errors->has('subcategory_id') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('subcategory_id')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('subcategory_id')); ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('icon_id', 'Icon *'); ?>
                <?php echo Form::file('icon_id', ['class' => $errors->has('photo_id') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('photo_id')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('photo_id')); ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('photo_id', 'Photo *'); ?>
                <?php echo Form::file('photo_id', ['class' => $errors->has('photo_id') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('photo_id')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('photo_id')); ?></div>
                <?php endif; ?>
            </div>


            <div class="form-group">
                <?php echo Form::label('released_on', 'Date of released *'); ?>
                <?php echo Form::date('released_on', null, ['class' => $errors->has('released_on') ? 'form-control is-invalid' : 'form-control']); ?>
                <?php if($errors->has('released_on')): ?>
                    <div class="invalid-feedback"><?php echo e($errors->first('released_on')); ?></div>
                <?php endif; ?>
            </div>


            <div class="form-group">
                <?php echo Form::token(); ?>
                <?php echo Form::submit('Create Product', ['class'=>'btn btn-primary btn-block']); ?>
            </div>


            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>


    <script>
        /**
         * Created by idgu on 10.12.2017.
         */

        function getSubcategories(categoryValue) {
            const subcategoriesSelect = document.querySelector('#my-subcategory');
            var xhr = new XMLHttpRequest();

            if (categoryValue !== '') {

                xhr.open('GET',  '<?php echo e(route('getSubcategories', null)); ?>' +'/' + categoryValue, true);

                xhr.onload = function() {
                    if (this.status == 200) {
                        subcategories = JSON.parse(this.responseText);
                        display = '<option value="" selected="selected">Choose Option</option>';
                        subcategories.forEach(function(subcategory) {
                            display += '<option value="'+ subcategory.id +'">' + subcategory.name +'</option>';
                        });

                        subcategoriesSelect.innerHTML = display;
                    }


                }
                xhr.send();
            } else {
                subcategoriesSelect.innerHTML = '<option value="" selected="selected">Choose Option</option>';
            }
        }



        document.addEventListener('DOMContentLoaded', function () {
            const category = document.querySelector('#my-category');

            getSubcategories(category.value);
            category.addEventListener('change', function () {
                getSubcategories(category.value);
            })
        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>